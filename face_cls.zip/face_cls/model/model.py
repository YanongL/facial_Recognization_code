import torch
import torch.nn as nn 
import timm
from efficientnet_pytorch import EfficientNet

class ResNext(nn.Module):
    def __init__(self, model_name='resnext50_32x4d', pretrained=False, n_class=11):
        super().__init__()
        self.model = timm.create_model(model_name, pretrained=pretrained)
        n_features = self.model.fc.in_features
        # 冻结前面的网络层
        # for param in self.model.parameters():
        #     param.requires_grad = False

        # 这里考虑加入global avg_pool 和 global max_pool丰富特征
        self.features = nn.Sequential(*list(self.model.children())[:-2])
        # self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        # self.reduce_layer = nn.Conv2d(4096, 2048, 1)
        self.dropout = nn.Dropout(0.3)
        self.fc = nn.Linear(n_features, n_class)

        # 微调后面两层
        # self.model.global_pool = torch.nn.AdaptiveAvgPool2d(1)
        # 目前最高的是下面这种fine-tune方式,替换全连接加dropout
        # self.model.fc = nn.Sequential(
        #     nn.Dropout(0.3),
        #     nn.Linear(n_features, n_class, bias=True)
        # )
        # self.model.fc = nn.Linear(n_features, n_class)

    def forward(self, x):
        # x = self.model(x)
        batch_size = x.size()[0]
        x = self.features(x)
        # x1 = self.avg_pool(x)
        x = self.max_pool(x).view(batch_size, -1)
        # x = torch.cat([x1, x2], dim=1)
        # x = self.reduce_layer(x).view(batch_size, -1) # 恢复到全连接的size[batch_size, 2048]
        x = self.fc(self.dropout(x))
        # x = self.model(x)

        return x

class SeResNext(nn.Module):
    def __init__(self, model_name='seresnext50_32x4d', pretrained=False, n_class=11):
        super().__init__()
        self.model = timm.create_model(model_name, pretrained=pretrained)
        n_features = self.model.fc.in_features
        self.model.fc = nn.Linear(n_features, n_class)

    def forward(self, x):
        x = self.model(x)
        return x

class ResNet(nn.Module):
    def __init__(self, model_name='resnet200d', pretrained=False, n_class=11):
        super().__init__()
        self.model = timm.create_model(model_name, pretrained=pretrained)
        n_features = self.model.fc.in_features
        self.model.fc = nn.Linear(n_features, n_class)

    def forward(self, x):
        x = self.model(x)
        return x

class Xception(nn.Module):
    def __init__(self, model_name='xception', pretrained=False, n_class=11):
        super().__init__()
        self.model = timm.create_model(model_name, pretrained=pretrained)
        n_features = self.model.fc.in_features
        self.model.fc = nn.Linear(n_features, n_class)

    def forward(self, x):
        x = self.model(x)
        return x


class EfficientNet(nn.Module):
    def __init__(self, model_name='efficientnet_b3', pretrained=False, n_class=11):
        super().__init__()
        self.model = timm.create_model(model_name, pretrained=pretrained)
        n_features = self.model.classifier.in_features
        self.model.classifier = nn.Linear(n_features, n_class)
        '''
        self.model.classifier = nn.Sequential(
            nn.Dropout(0.3),
            #nn.Linear(n_features, hidden_size,bias=True), nn.ELU(),
            nn.Linear(n_features, n_class, bias=True)
        )
        '''
    def forward(self, x):
        x = self.model(x)
        return x

def get_model(pretrained):
    model_name = 'efficientnet-b7'

    if pretrained:
        model = EfficientNet.from_pretrained(model_name, num_classes=5)
    else:
        model = EfficientNet.from_name(model_name, num_classes=5)

    return model

if __name__ == '__main__':
    test_model = ResNext()
    # test_data = torch.ones((1,3,224,2224)) # size is [batch, n_class]
    # print(test_model(test_data).size())
    # new_model = nn.Sequential(*list(test_model.modules())[:-3])
    # print(new_model)
    # print(list(test_model.named_modules())[-2:])
    # print(name, module)
    from torchvision.models import resnet50
    model = resnet50()
    print(list(test_model.children()))
        