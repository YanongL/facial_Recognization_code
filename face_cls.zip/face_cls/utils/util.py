from logging import getLogger, INFO, FileHandler,  Formatter,  StreamHandler
import argparse
import random
import os
import torch
import numpy as np
from sklearn.metrics import roc_auc_score
from data_process.process_data import label_list

def get_argparse():
    parser = argparse.ArgumentParser()
    ## Required parameters
    parser.add_argument("--data_dir", default=None, type=str, required=False,
                        help="The output directory where the model predictions and checkpoints will be written.")
    parser.add_argument("--saved_dir", default=None, type=str, required=False,
                        help="The output directory where the model predictions and checkpoints will be written.")
    parser.add_argument("--logs_dir", default=None, type=str, required=False,
                        help="The logs directory.")
    parser.add_argument("--model_name", default=None, type=str, required=False,
                        help="What model to use in training!")
    parser.add_argument("--image_size", default=256, type=int, required=False,
                        help="The image size using!")

    parser.add_argument("--weight_decay", default=1e-6, type=float,
                        help="Weight decay if we apply some.")
    parser.add_argument("--warmup_proportion", default=0.1, type=float,
                        help="Proportion of training to perform linear learning rate warmup for,E.g., 0.1 = 10% of training.")
    parser.add_argument("--lr", default=1e-4, type=float,
                        help="The initial learning rate for Adam.")
    parser.add_argument("--adam_epsilon", default=1e-8, type=float,
                        help="Epsilon for Adam optimizer.")
    parser.add_argument("--epochs", default=10, type=int,
                        help="Total number of training epochs to perform.")
    parser.add_argument("--warmup_steps", default=3, type=int,
                        help="Linear warmup over warmup_steps.")
    parser.add_argument("--seed", type=int, default=42,
                        help="random seed for initialization")

    parser.add_argument("--fp16", default=False, action="store_true",
                        help="Whether to use 16-bit (mixed) precision (through NVIDIA apex) instead of 32-bit")
    

    args = parser.parse_args()
    return args

def get_logger(logs_dir):
    if not os.path.exists(logs_dir):
        os.makedirs(logs_dir)
    log_file_path = os.path.join(logs_dir, 'train.log')
    logger = getLogger(__name__)
    logger.setLevel(INFO)
    handler1 = StreamHandler()
    handler1.setFormatter(Formatter("%(message)s"))
    handler2 = FileHandler(filename=log_file_path)
    handler2.setFormatter(Formatter("%(message)s"))
    logger.addHandler(handler1)
    logger.addHandler(handler2)
    return logger

def seed_everything(seed=42):
    '''
    设置整个开发环境的seed
    :param seed:
    :param device:
    :return:
    '''
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    # some cudnn methods can be random even after fixing the seed
    # unless you tell it to be deterministic
    torch.backends.cudnn.deterministic = True

def get_score(labels, preds):
    # 新的metrics计算方式
    return np.mean([roc_auc_score(labels[:, i], preds[:, i]) for i in range(11)])

def get_result(result_df):
    #计算local CV
    preds = result_df[['pred_{}'.format(c) for c in label_list]].values
    labels = result_df[label_list].values
    score = get_score(labels, preds)
    return score
