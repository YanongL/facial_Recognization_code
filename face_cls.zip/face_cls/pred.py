import torch
from torch.utils.data import DataLoader
from tqdm import tqdm
import numpy as np 
import os
import pandas as pd 
import random
from data_process.process_data import Cassava_dataset, get_transforms
from model.model import ResNext, SeResNext, EfficientNet

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# def load_state(model_path):
#     model = ResNext(, pretrained=False)
#     try:  # single GPU model_file
#         model.load_state_dict(torch.load(model_path)['model'], strict=True)
#         state_dict = torch.load(model_path)['model']
#     except:  # multi GPU model_file
#         state_dict = torch.load(model_path)['model']
#         state_dict = {k[7:] if k.startswith('module.') else k: state_dict[k] for k in state_dict.keys()}

#     return state_dict
def predict(model, states, test_loader, device):
    model.to(device)
    tk0 = tqdm(enumerate(test_loader), total=len(test_loader))
    probs = []
    for i, (images) in tk0:
        images = images.to(device)
        avg_preds = []
        for state in states:
            model.load_state_dict(state['model'])
            model.eval()
            with torch.no_grad():
                y_preds = model(images)
            avg_preds.append(y_preds.softmax(1).detach().cpu().numpy())
        avg_preds = np.mean(avg_preds, axis=0)
        probs.append(avg_preds)
    probs = np.concatenate(probs)
    return probs


if __name__ == '__main__':
    model_name = 'resnext50_32x4d'
    output_dir = './saved'
    test_data_path = './data/test_images'
    test_df_data = pd.read_csv('./sample_submission.csv')
    model = ResNext(model_name=model_name, pretrained=False)
    states = [torch.load(output_dir+f'{model_name}_fold{fold}_best.pth') for fold in range(5)]
    test_dataset = Cassava_dataset(test_df_data, test_data_path, transform=get_transforms(mode='test'), mode='test')
    test_loader = DataLoader(test_dataset, batch_size=1, shuffle=False, 
                                num_workers=4, pin_memory=True)
    predictions = predict(model, states, test_loader, device)
    # submission
    test_df_data['label'] = predictions.argmax(1)
    test_df_data[['image_id', 'label']].to_csv('./submission.csv', index=False)