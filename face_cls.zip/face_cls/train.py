import torch
import torch.nn as nn 
from torch.utils.data import DataLoader
import torch.optim as optim
from torch.cuda.amp import autocast, GradScaler 
from tqdm import tqdm
import numpy as np 
import os
import pandas as pd 
from sklearn.model_selection import GroupKFold
from sklearn.metrics import roc_auc_score
from torch.optim.lr_scheduler import ReduceLROnPlateau, CosineAnnealingWarmRestarts, CosineAnnealingLR
from data_process.process_data import Face_dataset, get_transforms, label_list
from model.model import ResNext, SeResNext, EfficientNet, Xception, ResNet
from utils.util import seed_everything, get_logger, get_argparse, get_result, get_score


# torch.cuda.set_device(1)
device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')


def train_epoch(model, train_dataloader, optimizer, loss_fn, scaler):
    # one epoch train
    model.train()
    train_pbar = tqdm(enumerate(train_dataloader), total=len(train_dataloader))
    train_losses = 0.0
    # all_labels = []
    # all_preds = []
    for step, (img, label) in train_pbar:
        optimizer.zero_grad()
        img = img.to(device, non_blocking=True)
        label = label.to(device, non_blocking=True)
        # print(label)
        # print(label.size())
        # torch.amp
        with autocast():
            out = model(img)
            loss = loss_fn(out, label)
        train_losses += loss.item()

        scaler.scale(loss).backward()
        # 梯度裁剪前需要调用下面这个
        scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1000)
        # all_preds.extend([out.sigmoid().detach().to('cpu').numpy()]) # 对记录的模型输出进行sigmoid处理
        # all_labels.extend([label.detach().cpu('cpu').numpy()])
        # optimizer.zero_grad()
        # loss.backward()
        # pytorch 自带加速
        # scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()
        # apex加速训练
        # with amp.scale_loss(loss, optimizer) as scaled_loss:
        #     scaled_loss.backward()
        # optimizer.step()
    # all_labels = np.concatenate(all_labels)
    # all_preds = np.concatenate(all_preds)
    # train_acc = np.mean(all_labels==all_preds)
    # train_score = get_score(all_labels, all_preds)

    # 清空GPU缓存
    torch.cuda.empty_cache()
    
    return train_losses / len(train_dataloader)
        

def val_epoch(model, val_dataloader, loss_fn):
    # one epoch val
    model.eval()
    val_pbar = tqdm(enumerate(val_dataloader), total=len(val_dataloader))
    val_losses = 0.0
    all_preds = []
    all_labels = []
    with torch.no_grad():
        for step, (img, label) in val_pbar:
            img = img.to(device, non_blocking=True)
            label = label.to(device, non_blocking=True)
            out = model(img)
            loss = loss_fn(out, label)
            val_losses += loss.item()
            # 保存预测的标签和样本label
            all_preds.extend([out.sigmoid().to('cpu').numpy()]) # 对记录的模型输出进行softmax处理
            all_labels.extend([label.to('cpu').numpy()])
        
        all_preds = np.concatenate(all_preds)
        all_labels = np.concatenate(all_labels)
        # print(all_labels.shape)
        # val_acc = np.mean(all_preds==all_labels)
        val_score = get_score(all_labels, all_preds)

    return val_losses / len(val_dataloader), val_score, all_preds

def train_loop(model, train_loader, val_loader, val_df, loss_fn, optimizer, scheduler, fold, args):
    # main train function
    logger.info('------------Fold {} Training is start!-------------'.format(fold))
    best_val_score = 0.0
    best_val_loss = np.inf
    scaler = GradScaler()
    for epoch in range(args.epochs):
        train_epoch_loss = train_epoch(model, train_loader, optimizer, loss_fn, scaler)
        val_epoch_loss, val_epoch_score, val_epoch_preds= val_epoch(model, val_loader, loss_fn)

        logger.info('Epoch {}: Train loss is {:.4f}, Val loss is {:.4f}' \
                                        .format(epoch+1, train_epoch_loss, val_epoch_loss))

        logger.info('Epoch {}: Val score is {:.4f}'.format(epoch+1, val_epoch_score))

        scheduler.step()
        # scheduler.step(val_epoch_loss)
        # scheduler_warmup.step()

        # if val_epoch_score > best_val_score:
        #     best_val_score = val_epoch_score
        #     logger.info('Best score is {:.4f}'.format(best_val_score))
        #     logger.info('Update model in epoch {}'.format(epoch+1))
        #     output_dir = os.path.join(args.saved_dir, args.model_name)
        #     if not os.path.exists(output_dir):
        #         os.makedirs(output_dir)
        #     saved_model_path = os.path.join(output_dir, 'fold_{}_best.pth'.format(fold))
        #     checkpoint = {
        #         'epoch': epoch + 1,
        #         'state_dict': model.state_dict(),
        #         'optim_state_dict': optimizer.state_dict(),
        #         'preds':val_epoch_preds,
        #         # 'amp': amp.state_dict()                    
        #     }
        #     torch.save(checkpoint, saved_model_path)


        if val_epoch_score > best_val_score:
            best_val_score = val_epoch_score
        if val_epoch_loss < best_val_loss:
            best_val_loss = val_epoch_loss
            logger.info('Best loss is {:.4f}'.format(best_val_loss))
            logger.info('Update model in epoch {}'.format(epoch+1))
            output_dir = os.path.join(args.saved_dir, args.model_name)
            if not os.path.exists(output_dir):
                os.makedirs(output_dir)
            saved_model_path = os.path.join(output_dir, 'fold_{}_best.pth'.format(fold))
            checkpoint = {
                'epoch': epoch + 1,
                'state_dict': model.state_dict(),
                'optim_state_dict': optimizer.state_dict(),
                'preds':val_epoch_preds,
                # 'amp': amp.state_dict()                    
            }
            torch.save(checkpoint, saved_model_path)
        
        # 清空GPU缓存
        torch.cuda.empty_cache()

    # 存储每个fold集中的最好的模型在val上的结果
    output_dir = os.path.join(args.saved_dir, args.model_name)
    check_point = torch.load(os.path.join(output_dir, 'fold_{}_best.pth'.format(fold)))
    val_df[['pred_{}'.format(c) for c in label_list]] = check_point['preds']

    logger.info('The Fold {} best loss is {:.4f}'.format(fold, best_val_loss))
    logger.info('The Fold {} best score is {:.4f}'.format(fold, best_val_score))
    logger.info('------------Fold {} Training is end!-------------'.format(fold))

    return val_df



def main(args):
    # main function
    seed_everything()
    df_data = pd.read_csv(os.path.join(args.data_dir, 'train.csv'))
    gkf = GroupKFold(n_splits=5)
    train_transforms = get_transforms(mode='train')
    val_transforms = get_transforms(mode='val')
    image_path = os.path.join(args.data_dir, 'train')
    oof_df = pd.DataFrame() # 用于存储每个fold的,每个最佳模型的val结果
    groups = df_data['PatientID'].values
    for fold, (train_index, val_index) in enumerate(gkf.split(df_data, df_data[label_list], groups)):
        
        # 加载数据
        train_df_data = df_data.iloc[train_index]
        val_df_data = df_data.iloc[val_index]
        val_df = val_df_data.reset_index(drop=True) # 生成val_df用于存储val的结果
        train_dataset = Face_dataset(train_df_data, image_path, transforms=train_transforms, mode='train')
        val_dataset = Face_dataset(val_df_data, image_path, transforms=val_transforms, mode='val')
        train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True, num_workers=4, pin_memory=True, drop_last=True)
        val_loader = DataLoader(val_dataset, batch_size=32, shuffle=False, num_workers=4, pin_memory=True, drop_last=False)

        # 设置模型及优化器
        logger.info('The model is using {}'.format(args.model_name))
        # model = EfficientNet(model_name=args.model_name, pretrained=True, n_class=len(label_list))
        # model = SeResNext(model_name=args.model_name, pretrained=True, n_class=len(label_list))
        model = ResNext(model_name=args.model_name, pretrained=True, n_class=len(label_list))
        # model = Xception(model_name=args.model_name, pretrained=True, n_class=len(label_list))
        # model = ResNet(model_name=args.model_name, pretrained=True, n_class=len(label_list))
        model.to(device)

        # 多卡并行训练
        # if torch.cuda.device_count() > 1:
        #     logger.info("Let's use", torch.cuda.device_count(), "GPUs!")
        #     model = nn.DataParallel(model)
        optimizer = optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
        # optimizer = RAdam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
        # optimizer = Lookahead(RAdam(model.parameters(),lr=0.00001), alpha=0.5, k=5)

        # scheduler进行lr调整
        # scheduler = ReduceLROnPlateau(optimizer, mode='min', patience=3)
        # scheduler = CosineAnnealingWarmRestarts(optimizer, T_0=10, T_mult=1, eta_min=1e-6, last_epoch=-1)
        scheduler = CosineAnnealingLR(optimizer, T_max=4, eta_min=1e-6, last_epoch=-1)

        # loss function
        loss_fn = nn.BCEWithLogitsLoss()

        # 使用apex加速训练
        # model, optimizer = amp.initialize(model, optimizer, opt_level='O1')

        # 记录参数以及优化器相关
        logger.info('The optimizer is {}'.format(optimizer))
        logger.info('The scheduler is {}'.format(scheduler))
        logger.info('The loss function is {}'.format(loss_fn))
        
        # 训练和保存结果
        _oof_df = train_loop(model, train_loader, val_loader, val_df, loss_fn, optimizer, scheduler, fold, args)
        oof_df = pd.concat([oof_df, _oof_df])
    # 保存oof result
    oof_df.to_csv('./oof_df.csv', index=False)
    logger.info('----------------CV result-----------------')
    logger.info('The Local CV result is {:.4f}'.format(get_result(oof_df)))
    logger.info('------------------------------------------')
    logger.info('All Training is End!')
    



if __name__ == '__main__':
    args = get_argparse()
    args.data_dir = './data'
    args.saved_dir = './saved'
    args.model_name = 'resnext50_32x4d'
    args.logs_dir = os.path.join('./logs', args.model_name)
    logger = get_logger(args.logs_dir)
    main(args)


