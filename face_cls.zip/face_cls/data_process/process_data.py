from torch.utils.data import Dataset
import pandas as pd 
import cv2
import os
import torch
import albumentations as A 
from albumentations import (
    Compose, OneOf, Normalize, Resize, RandomResizedCrop, RandomCrop, HorizontalFlip, VerticalFlip, CenterCrop,
    RandomBrightness, RandomContrast, RandomBrightnessContrast, Rotate, ShiftScaleRotate, Cutout, HueSaturationValue,
    IAAAdditiveGaussianNoise, CoarseDropout, Transpose
    )
from albumentations.pytorch import ToTensorV2


# A.Compose([
#     A.Transpose(p=0.5),
#     A.VerticalFlip(p=0.5),
#     A.HorizontalFlip(p=0.5),
#     A.RandomBrightness(limit=0.2, p=0.75),
#     A.RandomContrast(limit=0.2, p=0.75),
#     A.OneOf([
#         A.MotionBlur(blur_limit=5),
#         A.MedianBlur(blur_limit=5),
#         A.GaussianBlur(blur_limit=5),
#         A.GaussNoise(var_limit=(5.0, 30.0)),
#     ], p=0.7),

#     A.OneOf([
#         A.OpticalDistortion(distort_limit=1.0),
#         A.GridDistortion(num_steps=5, distort_limit=1.),
#         A.ElasticTransform(alpha=3),
#     ], p=0.7),

#     A.CLAHE(clip_limit=4.0, p=0.7),
#     A.HueSaturationValue(hue_shift_limit=10, sat_shift_limit=20, val_shift_limit=10, p=0.5),
#     A.ShiftScaleRotate(shift_limit=0.1, scale_limit=0.1, rotate_limit=15, border_mode=0, p=0.85),
#     A.Resize(image_size, image_size),
#     A.Cutout(max_h_size=int(image_size * 0.375), max_w_size=int(image_size * 0.375), num_holes=1, p=0.7),    
#     A.Normalize()
# ])
csv_columns = ['StudyInstanceUID', 'PatientID']

label_list = ['ETT - Abnormal', 'ETT - Borderline',
       'ETT - Normal', 'NGT - Abnormal', 'NGT - Borderline',
       'NGT - Incompletely Imaged', 'NGT - Normal', 'CVC - Abnormal',
       'CVC - Borderline', 'CVC - Normal', 'Swan Ganz Catheter Present']

class Face_dataset(Dataset):

    def __init__(self, df_data, data_path=None, transforms=None, mode='train'):
        super(Face_dataset, self).__init__()
        self.df_data = df_data
        self.data_path = data_path
        self.image_ids = self.df_data['StudyInstanceUID'].values
        self.labels = self.df_data[label_list].values
        self.mode = mode
        self.transforms = transforms

    def __len__(self):
        return len(self.df_data)

    def __getitem__(self, index):
        img_id = self.image_ids[index]
        label = self.labels[index]
        img_path = cv2.imread(os.path.join(self.data_path, img_id + '.jpg')) # 读取返回的是numpy.ndarray[H, W, C]
        img = cv2.cvtColor(img_path, cv2.COLOR_BGR2RGB) #[600,800,3]
        label = torch.tensor(label, dtype=torch.float)
        if self.transforms:
            argumented = self.transforms(image=img)
            img = argumented['image']
        if self.mode == 'train' or self.mode == 'val':
            return img, label
        elif self.mode == 'test':
            return img


def get_transforms(mode):
    
    if mode == 'train':
        return Compose([
            #Resize(CFG.size, CFG.size),
            # RandomResizedCrop(512, 512),
            RandomResizedCrop(512,512, scale=(0.85, 1.0)),
            # Transpose(p=0.5),
            HorizontalFlip(p=0.5),
            # VerticalFlip(p=0.5),
            # RandomContrast(limit=0.2, p=0.75),
            # ShiftScaleRotate(shift_limit=0.025, scale_limit=0.1, rotate_limit=10, p=0.5),
            # HueSaturationValue(hue_shift_limit=0.2, sat_shift_limit=0.2, val_shift_limit=0.2, p=0.5),
            # RandomBrightnessContrast(brightness_limit=(-0.1,0.1), contrast_limit=(-0.1, 0.1), p=0.5),
            # CoarseDropout(p=0.5),
            # Cutout(p=0.5),
            Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225],
            ),
            ToTensorV2(),
        ])

    elif mode == 'val' or mode == 'test':
        return Compose([
            Resize(512, 512),
            # CenterCrop(380,380, p=1.),
            Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225], 
            ),
            ToTensorV2(),
        ])





if __name__ == '__main__':
    df_data = pd.read_csv('../data/train.csv')
    # annotation_data = pd.read_csv('../data/train_annotations.csv')
    train_dataset = Face_dataset(df_data, '../data/train')
    print(type(train_dataset[0][0]))
    print(train_dataset[0][0].shape)
    # from sklearn.model_selection import StratifiedKFold, KFold
    # skf = StratifiedKFold(n_splits=5, random_state=442)
    # for i, (train_index, val_index) in enumerate(skf.split(df_data['image_id'], df_data['label'])):
    #     print(len(train_index))
    #     print(len(val_index))
    